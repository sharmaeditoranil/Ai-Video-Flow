import { strict as assert } from "node:assert";
import { test } from "node:test";
import { mkdtempSync, mkdirSync, readFileSync, rmSync, existsSync, writeFileSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { join, dirname } from "node:path";
import { tmpdir } from "node:os";
import { fileURLToPath } from "node:url";
import { recordInManifest } from "./lib/media-record.mjs";
import { resolveSfx } from "./lib/sfx.mjs";

// Proves the relocated engine (skills/media-use/audio/) still resolves its
// bundled SFX library from the moved location — the path most likely to break
// on a subtree move. Offline (heygenOK:false), no network.

const HERE = dirname(fileURLToPath(import.meta.url));
const sfxLibDir = join(HERE, "..", "assets", "sfx"); // same offset the engine uses

test("bundled SFX library resolves from the relocated path", async () => {
  assert.ok(existsSync(join(sfxLibDir, "manifest.json")), "moved manifest is present");
  const dir = mkdtempSync(join(tmpdir(), "mu-audio-"));
  try {
    const { sfx, anomalies } = await resolveSfx({
      cues: [{ id: "1", name: "whoosh" }],
      heygenOK: false,
      hyperframesDir: dir,
      sfxLibDir,
    });
    assert.equal(sfx.length, 1, `expected 1 resolved cue, got anomalies: ${anomalies.join("; ")}`);
    assert.equal(sfx[0].source, "local");
    assert.match(sfx[0].file, /assets\/sfx\//);
    assert.ok(existsSync(join(dir, sfx[0].file)), "matched SFX copied into the project");
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("an unknown cue is reported, not fatal", async () => {
  const dir = mkdtempSync(join(tmpdir(), "mu-audio-"));
  try {
    const { sfx, anomalies } = await resolveSfx({
      cues: [{ id: "1", name: "definitely-not-a-real-sfx" }],
      heygenOK: false,
      hyperframesDir: dir,
      sfxLibDir,
    });
    assert.equal(sfx.length, 0);
    assert.ok(anomalies.some((a) => /not in bundled library/.test(a)));
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("a person's own file under a bundled name survives, and the cue gets the next free name", async () => {
  const dir = mkdtempSync(join(tmpdir(), "mu-audio-"));
  try {
    const own = join(dir, "assets", "sfx", "whoosh.mp3");
    mkdirSync(dirname(own), { recursive: true });
    writeFileSync(own, "the person's own whoosh");
    const resolve = () =>
      resolveSfx({
        cues: [{ id: "1", name: "whoosh" }],
        heygenOK: false,
        hyperframesDir: dir,
        sfxLibDir,
      });

    const first = await resolve();
    const second = await resolve();

    assert.equal(readFileSync(own, "utf8"), "the person's own whoosh");
    assert.deepEqual(
      [first, second].map(({ sfx }) => [sfx[0].file, sfx[0].source]),
      [
        ["assets/sfx/whoosh-2.mp3", "local"],
        ["assets/sfx/whoosh-2.mp3", "local"],
      ],
    );
    assert.deepEqual(
      readFileSync(join(dir, "assets/sfx/whoosh-2.mp3")),
      readFileSync(join(sfxLibDir, "whoosh.mp3")),
    );
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("two effects never share a file when one's name is taken by the person, run after run", async () => {
  const dir = mkdtempSync(join(tmpdir(), "mu-audio-"));
  try {
    mkdirSync(join(dir, "assets", "sfx"), { recursive: true });
    writeFileSync(join(dir, "assets", "sfx", "glitch.mp3"), "the person's own glitch");
    const realFetch = globalThis.fetch;
    globalThis.fetch = async (url) => {
      const query = new URL(url).searchParams.get("query");
      if (query)
        return Response.json({ data: [{ audio_url: `https://sound.test/${query}`, score: 0.6 }] });
      return new Response(`bytes of ${new URL(url).pathname}`);
    };
    const run = async (names) => {
      const { sfx } = await resolveSfx({
        cues: names.map((name, index) => ({ id: String(index), name })),
        heygenOK: true,
        headers: {},
        hyperframesDir: dir,
        sfxLibDir,
      });
      const files = sfx.map(({ file }) => file);
      recordInManifest(
        dir,
        [...new Set(files)].map((path) => ({ path, type: "sfx", source: "search" })),
      );
      return files;
    };
    try {
      assert.deepEqual(await run(["glitch"]), ["assets/sfx/glitch-2.mp3"]);
      assert.deepEqual(await run(["glitch", "glitch 2", "glitch"]), [
        "assets/sfx/glitch-2.mp3",
        "assets/sfx/glitch-2-2.mp3",
        "assets/sfx/glitch-2.mp3",
      ]);
    } finally {
      globalThis.fetch = realFetch;
    }
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

// The engine owns speed parsing; a fallback before the check would turn 0 or junk into 1.
function runEngineWith(request, ...args) {
  const dir = mkdtempSync(join(tmpdir(), "audio-speed-range-"));
  try {
    writeFileSync(join(dir, "audio_request.json"), JSON.stringify({ lines: [], ...request }));
    return spawnSync(process.execPath, [join(HERE, "audio.mjs"), "--hyperframes", dir, ...args], {
      encoding: "utf8",
    });
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
}

for (const [label, request, args, shown] of [
  ["request speed 5", { speed: 5 }, [], "5"],
  ["request speed 0", { speed: 0 }, [], "0"],
  ["request speed -1", { speed: -1 }, [], "-1"],
  ["request speed text", { speed: "fast" }, [], '"fast"'],
  ["--speed 0", {}, ["--speed", "0"], '"0"'],
  ["--speed text", { speed: 1 }, ["--speed", "abc"], '"abc"'],
]) {
  test(`${label} stops the engine before any TTS runs`, () => {
    const r = runEngineWith(request, ...args);
    assert.equal(r.status, 1);
    assert.ok(r.stderr.includes(`speed must be above 0 and at most 3, got ${shown}`), r.stderr);
  });
}

test("a numeric string speed, as the adapters forward it, passes the check", () => {
  assert.doesNotMatch(runEngineWith({ speed: "0.8" }, "--only", "tts").stderr, /speed must/);
});
